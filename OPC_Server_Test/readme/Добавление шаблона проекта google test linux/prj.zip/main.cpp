#include <cstdio>

int main()
{
    printf("hello from prj!\n");
    return 0;
}